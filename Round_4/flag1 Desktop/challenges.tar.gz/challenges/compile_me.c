#include <stdio.h>
int main()
{
   // printf() displays the string inside quotation
   printf("YOU SUCCESSFULLY COMPILED ME\n");
   return 0;
}
